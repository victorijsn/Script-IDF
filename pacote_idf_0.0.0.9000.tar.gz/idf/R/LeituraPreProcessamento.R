#' Leitura & Verificação do banco de dados.
#'
#' Esta função lê o banco de dados original diretamente do diretório onde se encontra o arquivo em seu computador. A saída dessa função será utilizada como entrada (*input*) na função *IDF(dados = , lin_pextr = , sal_min =...)*.
#' Além disso, a função verifica se todas as variáveis necessárias para o cálculo estão presentes no banco de dados. Caso haja variáveis desnecessárias, a função irá eliminá-las. Caso algumas variáveis estejam ausentes, a função indicará o nome das mesmas. Recomenda-se a utilização dessa função antes da função *IDF( ... )*.
#'
#'
#' @param endereco_arquivo Endereço do banco de dados em seu computador.
#' @return Retorna o banco de dados apenas com as variáveis necessárias para o cálculo do IDF que deverá ser inserido, posteriormente, na função *IDF( ... )*.  Caso a função identifique alguma variável faltante, ela indicará o nome da mesma.
#' @export
#' @examples dados <- LeituraPreProcessamento(endereco_arquivo = "C:/.../seu_arquivo.csv")

LeituraPreProcessamento <- function(endereco_arquivo){


nomes   <- c("dta_nasc_pessoa",                  "dat_atual_fam",
             "dat_cadastramento_fam",            "cd_ibge",
             "d.cod_familiar_fam",               "cod_familia_indigena_fam",
             "cod_est_cadastral_fam",            "cod_especie_domic_fam",
             "cod_material_domic_fam",           "cod_abaste_agua_domic_fam",
             "cod_banheiro_domic_fam",           "cod_escoa_sanitario_domic_fam",
             "cod_destino_lixo_domic_fam",       "cod_iluminacao_domic_fam",
             "cod_calcamento_domic_fam",         "cod_est_cadastral_memb",
             "cod_deficiencia_memb",             "cod_parentesco_rf_pessoa",
             "cod_local_nascimento_pessoa",      "cod_sabe_ler_escrever_memb",
             "cod_curso_frequenta_memb",         "cod_ano_serie_frequenta_memb",
             "cod_curso_frequentou_pessoa_memb", "cod_concluiu_frequentou_memb",
             "cod_ano_serie_frequentou_memb",    "cod_trabalhou_memb",
             "cod_afastado_trab_memb",           "cod_principal_trab_memb",
             "cod_agricultura_trab_memb",        "ind_trabalho_infantil_pessoa",
             "ind_frequenta_escola_memb",        "ind_familia_quilombola_fam",
             "val_remuner_emprego_memb",         "val_renda_bruta_12_meses_memb",
             "val_renda_doacao_memb",            "val_renda_aposent_memb",
             "val_renda_seguro_desemp_memb",     "val_renda_pensao_alimen_memb",
             "val_desp_energia_fam",             "val_desp_agua_esgoto_fam",
             "val_desp_gas_fam",                 "val_desp_alimentacao_fam",
             "val_desp_transpor_fam",            "val_desp_aluguel_fam",
             "val_desp_medicamentos_fam",        "val_outras_rendas_memb",
             "vlr_renda_media_fam",              "qtd_pessoas_domic_fam",
             "qtd_pessoa_inter_0_17_anos_fam",   "qtd_pessoa_inter_18_64_anos_fam",
             "qtd_pessoa_inter_65_anos_fam",     "qtd_comodos_dormitorio_fam",
             "num_nis_pessoa_atual")

suppressWarnings({
matriz.dados <- fread(endereco_arquivo , select = nomes,
                      colClasses=c(dta_nasc_pessoa="character",        dat_atual_fam="character",
                           dat_cadastramento_fam="character",          cd_ibge="numeric",
                           d.cod_familiar_fam="numeric",               cod_familia_indigena_fam="numeric",
                           cod_est_cadastral_fam="numeric",            cod_especie_domic_fam="numeric",
                           cod_material_domic_fam="numeric",           cod_abaste_agua_domic_fam="numeric",
                           cod_banheiro_domic_fam="numeric",           cod_escoa_sanitario_domic_fam="numeric",
                           cod_destino_lixo_domic_fam="numeric",       cod_iluminacao_domic_fam="numeric",
                           cod_calcamento_domic_fam="numeric",         cod_est_cadastral_memb="numeric",
                           cod_deficiencia_memb="numeric",             cod_parentesco_rf_pessoa="numeric",
                           cod_local_nascimento_pessoa="numeric",      cod_sabe_ler_escrever_memb="numeric",
                           cod_curso_frequenta_memb="numeric",         cod_ano_serie_frequenta_memb="numeric",
                           cod_curso_frequentou_pessoa_memb="numeric", cod_concluiu_frequentou_memb="numeric",
                           cod_ano_serie_frequentou_memb="numeric",    cod_trabalhou_memb="numeric",
                           cod_afastado_trab_memb="numeric",           cod_principal_trab_memb="numeric",
                           cod_agricultura_trab_memb="numeric",        ind_trabalho_infantil_pessoa="numeric",
                           ind_frequenta_escola_memb="numeric",        ind_familia_quilombola_fam="numeric",
                           val_remuner_emprego_memb="numeric",         val_renda_bruta_12_meses_memb="numeric",
                           val_renda_doacao_memb="numeric",            val_renda_aposent_memb="numeric",
                           val_renda_seguro_desemp_memb="numeric",     val_renda_pensao_alimen_memb="numeric",
                           val_desp_energia_fam="numeric",             val_desp_agua_esgoto_fam="numeric",
                           val_desp_gas_fam="numeric",                 val_desp_alimentacao_fam="numeric",
                           val_desp_transpor_fam="numeric",            val_desp_aluguel_fam="numeric",
                           val_desp_medicamentos_fam="numeric",        val_outras_rendas_memb="numeric",
                           vlr_renda_media_fam="numeric",              qtd_pessoas_domic_fam="numeric",
                           qtd_pessoa_inter_0_17_anos_fam="numeric",   qtd_pessoa_inter_18_64_anos_fam="numeric",
                           qtd_pessoa_inter_65_anos_fam="numeric",     qtd_comodos_dormitorio_fam="numeric",
                           num_nis_pessoa_atual = "numeric"))
}) #fim suppressWarnings

################# TRANSFORMANDO CHARACTER EM DATE VIA TYDIVERSE ###################################
# Verificando se formato é YYYY/MM/DD ou DD/MM/YYYY. Sorteio uma posição
#aleatório e verificado formato. Transformando character em
# date. As vezes o R importa com ordem diferente,
# inviabilizando assim as rotinas do pacote.
suppressWarnings({
pos <- floor(runif(1, min = 0,max = dim(matriz.dados)[1]))
# dat_cadastramento_fam
if(is.na(parse_date_time(matriz.dados$dat_cadastramento_fam[pos], orders="dmy")) ==TRUE){
  matriz.dados$dat_cadastramento_fam <- lubridate::ymd(matriz.dados$dat_cadastramento_fam , quiet = TRUE)
}else{
  matriz.dados$dat_cadastramento_fam <- lubridate::dmy(matriz.dados$dat_cadastramento_fam , quiet = TRUE)
}
#dta_nasc_pessoa
if(is.na(parse_date_time(matriz.dados$dta_nasc_pessoa[pos], orders="dmy")) ==TRUE){
  matriz.dados$dta_nasc_pessoa <- lubridate::ymd(matriz.dados$dta_nasc_pessoa , quiet = TRUE)
}else{
  matriz.dados$dta_nasc_pessoa <- lubridate::dmy(matriz.dados$dta_nasc_pessoa , quiet = TRUE)
}
#dat_atual_fam
if(is.na(parse_date_time(matriz.dados$dat_atual_fam[pos], orders="dmy")) ==TRUE){
  matriz.dados$dat_atual_fam <- lubridate::ymd(matriz.dados$dat_atual_fam , quiet = TRUE)
}else{
  matriz.dados$dat_atual_fam <- lubridate::dmy(matriz.dados$dat_atual_fam , quiet = TRUE)
}
}) #fim suppressWarnings

# Elaborando AVISOS DE PROBLEMA DE LEITURA NOS DADOS.
# print() do numero de datas em 'dat_cadastramento_fam' que estão com formato errado no banco de dados original.
parseprob1 <- length(which(is.na(matriz.dados$dat_cadastramento_fam)==TRUE))
if(parseprob1 != 0){
print(paste("Warning message: A variável dat_cadastramento_fam possui",parseprob1,"erros de preenchimento no banco de dados original. As correspondentes datas foram tratadas como NA (missing values). Recomenda-se a revisão do banco de dados original.", sep=" "))
}

# print() do numero de datas em 'dta_nasc_pessoa' que estão com formato errado no banco de dados original.
parseprob2 <- length(which(is.na(matriz.dados$dta_nasc_pessoa)==TRUE))
if(parseprob2 != 0){
  print(paste("Warning message: A variável dta_nasc_pessoa possui",parseprob2,"erros de preenchimento no banco de dados original. As correspondentes datas foram tratadas como NA (missing values). Recomenda-se a revisão do banco de dados original.", sep=" "))
}

# print() do numero de datas em 'dat_atual_fam' que estão com formato errado no banco de dados original.
parseprob3 <- length(which(is.na(matriz.dados$dat_atual_fam)==TRUE))
if(parseprob3 != 0){
  print(paste("Warning message: A variável dat_atual_fam possui",parseprob3,"erros de preenchimento no banco de dados original. As correspondentes datas foram tratadas como NA (missing values). Recomenda-se a revisão do banco de dados original." , sep=" "))
}




# VERIFICA SE HÁ ALGUMA VARIÁVEL NECESSÁRIA PARA ESTIMAÇÃO DO
# DO IDF QUE NÃO ESTA PRESENTE NO BANCO DE DADOS
var_faltantes <- base::setdiff(nomes,names(matriz.dados))

#Preparando texto e nomes das variáveis faltantes.
if((dim(matriz.dados)[2] - length(nomes)) != 0 ){
    aux1 <- c(" AS SEGUINTES VARIÁVEIS ESTÃO AUSENTES NO BANCO DE DADOS:        ")
    aux2 <- paste(" [",1,"] ",var_faltantes[1],",",sep="")
  for (i in 2:(length(var_faltantes)-1)){
    aux2 <- paste(aux2, " [",i,"] ", var_faltantes[i],",", sep="")
  }
    aux2 <- paste(aux2, " [",length(var_faltantes),"] ", var_faltantes[length(var_faltantes)],".", sep="")

texto_saida_erro <- paste(aux1,aux2)
} #fim do IF

# Saída da função
if ( (dim(matriz.dados)[2] - length(nomes)) != 0 ){
      print(texto_saida_erro)
  }else{
    out <- as.data.frame(matriz.dados)
  return(out) # matriz que será usada para estimado. Não contém erros no processo de leitura de dados
  } #fim else
}
