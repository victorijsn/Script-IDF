#' Banco de dados ilustrativo.
#'
#' Banco de dados ilustrativo com as variáveis necessárias para o cálculo do IDF.
#' É importante ressaltar que os valores atribuídos as respectivas variáveis foram
#' gerados de forma aleatória e portanto, não correspondem as informações de nenhuma
#' famílis específica.\cr
#' As variáveis necessárias para a estimação do IDF são: \cr
#' \itemize{
#' \item \code{dta_nasc_pessoa} = Data do nascimento da pessoa.
#' \item \code{dat_atual_fam} = Data da última atualização da família.
#' \item \code{dat_cadastramento_fam} = Data de cadastramento da família.
#' \item \code{cd_ibge} = Código do IBGE do município.
#' \item \code{d.cod_familiar_fam} = Código familiar.
#' \item \code{cod_familia_indigena_fam} = Família Indigena. 1 - Sim, 2 - Não.
#' \item \code{cod_est_cadastral_fam} = Estado cadastral da família. 2 - Sem Registro Civil, 3 - Cadastrado.
#' \item \code{cod_especie_domic_fam} = Especie do domicílio. 1 - Particular Permanente, 2 - Particular improvisado, 3 - Coletivo.
#' \item \code{cod_material_domic_fam} = Material predominante nas paredes externas do domicílio. 1 - Alvenaria/tijolo com revestimento, 2 - Alvenaria/tijolo sem revestimento, 3 - Madeira aparelhada, 4 - Taipa revestida, 5 - Taipa não revestida, 6 - Madeira aproveitada, 7 - Palha, 8 - Outro Material.
#' \item \code{cod_abaste_agua_domic_fam} = Forma de abastecimento de água. 1 - Rede geral de distribuição, 2 - Poço ou nascente, 3 - Cisterna, 4 - Outra forma.
#' \item \code{cod_banheiro_domic_fam} = Existência de banheiro. 1 - Sim, 2 - Não.
#' \item \code{cod_escoa_sanitario_domic_fam} = Forma de escoamento sanitário. 1 - Rede coletora de esgoto ou pluvial, 2 - Fossa séptica, 3 - Fossa rudimentar, 4 - Vala a céu aberto, 5 - Direto para um rio, lago ou mar, 6 - Outra forma.
#' \item \code{cod_destino_lixo_domic_fam} = Forma de coleta do lixo. 1 - É coletado diretamente, 2 - É coletado indiretamente, 3 - É queimado ou enterrado na propriedade, 4 - É jogado em terreno baldio ou logradouro (rua, avenida, etc.), 5 - É jogado em rio ou mar, 6 - Tem outro destino.
#' \item \code{cod_iluminacao_domic_fam} = Tipo de iluminação - Elétrica com medidor próprio, 2 - Elétrica com medidor comunitário, 3 - Elétrica sem medidor, 4 - Óleo, querosene ou gás, 5 - Vela, 6 - Outra forma.
#' \item \code{cod_calcamento_domic_fam} = Calcamento em frente ao seu domicílio 1 - Total, 2 - Parcial, 3 - Não existe.
#' \item \code{cod_est_cadastral_memb} = Estado cadastral da pessoa. 2 - Sem Registro Civil, 3 - Cadastrado, 5 - Aguardando NIS, 6 - Validando NIS.
#' \item \code{cod_deficiencia_memb} = Pessoa tem deficiência? 1 - Sim, 2 - Não.
#' \item \code{cod_parentesco_rf_pessoa} = Relação de parentesco com o responsavel familiar. 1 - Pessoa Responsável pela Unidade Familiar - RF, 2 - Cônjuge ou companheiro(a), 3 - Filho(a), 4 - Enteado(a), 5 - Neto(a) ou bisneto(a), 6 - Pai ou mae, 7 - Sogro(a), 8 - Irmão ou irmã, 9 - Genro ou nora, 10 - Outro parente, 11 - Não parente.
#' \item \code{cod_local_nascimento_pessoa} = Local de nascimento. 1 - Neste município, 2 - Em outro município, 3 - Em outro pais.
#' \item \code{cod_sabe_ler_escrever_memb} = Pessoa sabe ler e escrever. 1 - Sim, 2 - Não.
#' \item \code{cod_curso_frequenta_memb} = Curso que a pessoa frequenta. 1 - Creche, 2 - Pré-escola (exceto CA), 3 - Classe de Alfabetização - CA, 4 - Ensino Fundamental regular (duração 8 anos), 5 - Ensino Fundamental regular (duração 9 anos), 6 - Ensino Fundamental especial, 7 - Ensino Médio regular, 8 - Ensino Médio especial, 9 - Ensino Fundamental EJA - séries iniciais (Supletivo - 1º a 4º), 10 - Ensino Fundamental EJA - séries finais (Supletivo - 5º a 8º), 11 - Ensino Médio EJA (Supletivo), 12 - Alfabetização para adultos(Mobral, etc.), 13 - Superior, Aperfeicoamento,Especialização, Mestrado,Doutorado, 14 - Pre-vestibular
#' \item \code{cod_ano_serie_frequenta_memb} = Ano e serie do curso que a pessoa frequenta. 1 - Primeiro(a), 2 - Segundo(a), 3 - Terceiro(a), 4 - Quarto(a), 5 - Quinto(a), 6 - Sexto(a), 7 - Setimo(a), 8 - Oitavo(a), 9 - Nono(a), 10 - Curso Não-seriado
#' \item \code{cod_curso_frequentou_pessoa_memb} = Curso mais elevado que a pessoa frequentou. 1 - Creche, 2 - Pre-escola (exceto CA), 3 - Classe de Alfabetização - CA, 4 - Ensino Fundamental 1º a 4º series, Elementar (Primario), Primeira fase do 1º grau, 5 - Ensino Fundamental 5º a 8º series, Médio 1º ciclo (Ginasial), Segunda fase do 1º grau, 6 - Ensino Fundamental (duração 9 anos),  7 - Ensino Fundamental Especial, 8 - Ensino Médio, 2º grau, Médio 2º ciclo (Cientifico, Classico, Tecnico, Normal), 9 - Ensino Médio Especial, 10 - Ensino Fundamental EJA -series iniciais (Supletivo 1º a 4º), 11 - Ensino Fundamental EJA -series finais (Supletivo 5º a 8º), 12 - Ensino Médio EJA(Supletivo), 13 - Superior, Aperfeicoamento, Especialização, Mestrado, Doutorado, 14 - Alfabetização para Adultos (Mobral, etc.), 15 - Nenhum.
#' \item \code{cod_concluiu_frequentou_memb} = A pessoa concluiu o curso? 1 - Sim, 2 - Não.
#' \item \code{cod_ano_serie_frequentou_memb} = Último ano e série do curso que a pessoa frequentou. 1 - Primeiro(a), 2 - Segundo(a), 3 - Terceiro(a), 4 - Quarto(a), 5 - Quinto(a), 6 - Sexto(a), 7 - Setimo(a), 8 - Oitavo(a), 9 - Nono(a), 10 - Curso Não-seriado
#' \item \code{cod_trabalhou_memb} = Pessoa trabalhou na semana passada? 1 - Sim, 2 - Não.
#' \item \code{cod_afastado_trab_memb} = Pessoa estava afastada na semana passada? 1 - Sim, 2 - Não.
#' \item \code{cod_principal_trab_memb} = Função principal. 1 - Trabalhador por conta propria (bico, autonomo), 2 - Trabalhador temporario em area rural, 3 - Empregado sem carteira de trabalho assinada, 4 - Empregado com carteira de trabalho assinada, 5 - Trabalhador domestico sem carteira de trabalho assinada, 6 - Trab. domestico com cart. de trab. assinada, 7 - Trabalhador Não-remunerado, 8 - Militar ou servidor publico, 9 - Empregador, 10 - Estagiario, 11 - Aprendiz
#' \item \code{cod_agricultura_trab_memb} = Atividade extrativista. 1 - Sim, 2 - Não.
#' \item \code{ind_trabalho_infantil_pessoa} = Pessoa com marcação de trabalho infantil. 1 - Sim, 2 - Não.
#' \item \code{ind_frequenta_escola_memb} = Pessoa frequenta escola. 1 - Sim, rede publica, 2 - Sim, rede particular, 3 - Não, ja frequentou, 4 - Nunca frequentou
#' \item \code{ind_familia_quilombola_fam} = família quilombola. 1 - Sim, 2 - Não.
#' \item \code{val_remuner_emprego_memb} = Valor de remuneração do mês passado do trabalho principal (sem casas decimais).
#' \item \code{val_renda_bruta_12_meses_memb} = Remuneração bruta de todos os trabalhos nos últimos 12 meses (sem casas decimais).
#' \item \code{val_renda_doacao_memb} = Valor recebido de doação (sem casas decimais).
#' \item \code{val_renda_aposent_memb} = Valor recebido de aposentadoria (sem casas decimais).
#' \item \code{val_renda_seguro_desemp_memb} = Valor recebido de seguro desemprego (sem casas decimais).
#' \item \code{val_renda_pensao_alimen_memb} = Valor recebido de pensao alimentícia (sem casas decimais).
#' \item \code{val_desp_energia_fam} = Valor de despesas com energia.
#' \item \code{val_desp_agua_esgoto_fam} = Valor de despesas com agua.
#' \item \code{val_desp_gas_fam} = Valor de despesas com gás.
#' \item \code{val_desp_alimentacao_fam} = Valor de despesas com alimentação.
#' \item \code{val_desp_transpor_fam} = Valor de despesas com transporte.
#' \item \code{val_desp_aluguel_fam} = Valor de despesas com aluguel.
#' \item \code{val_desp_medicamentos_fam} = Valor de despesas com medicamentos.
#' \item \code{val_outras_rendas_memb} = Valor recebido de outras fontes (sem casas decimais).
#' \item \code{vlr_renda_media_fam} = Valor da renda familiar per capita.
#' \item \code{qtd_pessoas_domic_fam} = Quantidade de pessoas no domicílio.
#' \item \code{qtd_pessoa_inter_0_17_anos_fam} = Quantidade de pessoas internadas faixa 0-17 anos.
#' \item \code{qtd_pessoa_inter_18_64_anos_fam} = Quantidade de pessoas internadas faixa 18-64 anos.
#' \item \code{qtd_pessoa_inter_65_anos_fam} = Quantidade de pessoas internadas faixa a partir de 65 anos.
#' \item \code{qtd_comodos_dormitorio_fam} = Comodo servindo como dormitório do domicílio.
#' \item \code{num_nis_pessoa_atual} = Número do NIS da pessoa.
#' }
#'
#' @docType data
#'
#' @usage data(CadUnIDF)
#'
#' @keywords datasets
#'
#' @examples
#' data(CadUnIDF)
"CadUnIDF"
