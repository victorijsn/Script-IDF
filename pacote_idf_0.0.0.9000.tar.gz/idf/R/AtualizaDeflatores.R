AtualizaDeflatores <- function(dados, tib_D, dataref_dados, ano_inicial){
  # Essa funcao cria os deflatores e adiciona aos tiblle(dados) os correspondentes deflatores de acordo
  # com os meses de "dat_atual_fam".
  # Função interna. Não é necessário chama-lá Essa função calcula os deflatores e os associa à base_domicilios e base_pessoas.
  #
  # dados Matriz Original (base domicílios + base pessoas=banco original) obtida no sistema.
  #  tib_D Matriz equivalente a base domicílios calculada a partir da Matriz Original (banco de dados original). Essa conversão é realizada internamente na função IDF.
  #  dataref_dados Ano e mês (YYY-MM-DD) base utilizados para cálculo dos deflatores.
  #  ano_inicial Ano inicial igual ao declarado na funciona IDF principal.

  #iniício função
  data_inicial <- paste(ano_inicial,"-01-01",sep="")

  # PARTE I - Manipulando dados BACEN e gerando deflatores.
  # Coleta no BACEN a série de INPC
  # 188 é o número da séries do BACEN - varianção %
  inpc <- BETSget(188 , from = data_inicial, to = dataref_dados, data.frame = TRUE)

  # Verificando se data de referência (dataref_dados) é menor ou igual a última data da inflação.
  YearMonth_lim_inpc <- max(format(as.Date(inpc$date), "%Y-%m")) # ultima data disponível do INPC.
  YearMonth_lim_ref <- format(as.Date(dataref_dados), "%Y-%m") # ano e mês de referência.
  if( YearMonth_lim_ref > YearMonth_lim_inpc ){
  stop(paste("A Data de Referência (dataref_dados) é maior do que a última data do INPC disponibilizada pelo BACEN. A data de referência deve ser menor do que: ", max(inpc$date), sep=" "))
    }

  # datas e inpc
  datas <- seq.Date(from=lubridate::ymd(data_inicial),to=lubridate::ymd(dataref_dados),by="month")
  tam <- dim(inpc)[1]

  matrix.inpc <- cbind(month(datas),year(datas),inpc)
  colnames(matrix.inpc) <- c("mes","ano","data","inpc")
  matrix.inpc <- as_tibble(matrix.inpc)

  #calculo do indice
  aux <- matrix(NA,ncol=1,nrow=tam)
  aux[1,1] <- 1
  for (i in 2:tam){
    aux[i,1] <- aux[i-1,1]*(1 + matrix.inpc$inpc[i]/100)
  }
  # INDICE
  matrix.inpc$INDICE <- aux

  #INDICE_BASE_DIV
  indice_base <- as.numeric(filter(matrix.inpc, mes == month(dataref_dados),
                                   ano == year(dataref_dados))$INDICE)

  matrix.inpc$INDICE_BASE_DIV <- matrix.inpc$INDICE/indice_base

  #INDICE_BASE_MULT
  matrix.inpc$INDICE_BASE_MULT <- 1/matrix.inpc$INDICE_BASE_DIV

  #DEFLATOR
  matrix.inpc$deflatores <- matrix.inpc$INDICE_BASE_MULT

  ## PARTE II - Inserindo deflatores no banco de dados original
  #mes3 e ano3 são "keys" para fazer o left_join
  dados$mes3 <- month(dataref_dados)
  dados$ano3 <- year(dataref_dados)

  tib_D$mes3 <- month(dataref_dados)
  tib_D$ano3 <- year(dataref_dados)

  #fazendo o merge. Colocando os correspondentes deflatores de acordo com ANO CADASTRO FAMILIA
  dados.aux <- left_join(dados, matrix.inpc, by=c("mes3"="mes", "ano3"="ano"))
  #fazendo o merge. Colocando os correspondentes deflatores de acordo com ANO CADASTRO DOMICILIOS
  D.aux <- left_join(tib_D,matrix.inpc,by=c("mes3"="mes", "ano3"="ano"))

  # Analisando deflatores após "Merge"
  #VERIFICANDO SE ALGUM DEFLATOR = NaN.
  if(any(is.na(dados.aux$deflatores)==TRUE)){ stop("variavel deflatores possui NA. Possivel problema no match das variáveis keys: c('mes3','ano3')")}

  #VERIFICANDO SE ALGUM DEFLATOR < 1
  if(any(dados.aux$deflatores < 0)){ stop("Variável deflatores possui NA. possivel problema no match das variáveis keys: c('mes3','ano3')")}

  # Preparando saidas
  out <- list()
  out$dados <- dados.aux # Inserindo os deflatores no banco de dados das pessoas
  out$D  <- D.aux  #Inserindo os deflatores no banco de dados das pessoas

  return(out)

} #fim da funcao
